# filters-tool
Calculates filters using 

## Requirements
To automatically install all python requirements you can run the pip command:

* pip install -r requirements

Note: For this the requirements file is needed, which can be found in the repository root!

## HowTo
Refer to the manual located inside the docs folder

## Authors
* Farall, Facundo David
* Kammann, Lucas Agustín
* Maselli, Carlos Javier